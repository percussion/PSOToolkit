This is the PSOToolkit for Rhythmyx 6.0.  Routines will be added here
as we find uses for them.  

To deploy the toolkit, unzip the distribution into a new subdirectory. 

You must have Java 1.5 and Apache Ant properly intstalled. The RHYTHMYX_HOME
environment variable must point at your Rhythmyx 6.0 installation.  

Type the command: 

ant -f deploy.xml 